﻿Public Class Game
    Public Property Target As Control

    Private Sub Target_Paint(ByVal sender As Object, ByVal e As PaintEventArgs)
        Enemys.ForEach(Sub(rect) DrawEnemy(e.Graphics, rect))
        DrawMe(e.Graphics, MyRect)
        DrawInfo(e.Graphics, e.ClipRectangle)
    End Sub

    Private rnd As New Random()

    Private WithEvents frameTimer As New Timers.Timer(50.0R) '0.5秒ごとに再描画
    Private WithEvents levelTimer As New Timers.Timer(3000.0R) '3秒ごとにレベルアップ
    Private WithEvents keyChangeTimer As New Timers.Timer(20000.0R) '20秒ごとにキー変更

    Public Sub Start()
        Level = 1
        Life = 3
        Const MY_RECT_SIZE As Integer = 24
        MyRect = New Rectangle(CInt(Target.ClientSize.Width / 2 - MY_RECT_SIZE / 2), Target.ClientRectangle.Bottom - MY_RECT_SIZE, MY_RECT_SIZE, MY_RECT_SIZE)
        AddHandler Me.Target.Paint, AddressOf Target_Paint
        AddHandler Me.Target.KeyPress, AddressOf Target_KeyPress
        Enemys.Clear()
        CreateAndSetKey()
        frameTimer.Start()
        levelTimer.Start()
        keyChangeTimer.Start()
    End Sub

    Public Sub [Stop]()
        frameTimer.Stop()
        levelTimer.Stop()
        keyChangeTimer.Stop()
        RemoveHandler Me.Target.Paint, AddressOf Target_Paint
        RemoveHandler Me.Target.KeyPress, AddressOf Target_KeyPress
    End Sub

    Private _keys As DirectionKeys
    Public ReadOnly Property DirectionKeys As DirectionKeys
        Get
            Return _keys
        End Get
    End Property

    Public Event DirectionKeysChanged As EventHandler

    Public Event GameOver As EventHandler

    Protected Sub CreateAndSetKey()
        Dim hs As New HashSet(Of Integer)()
        While hs.Count <> 4
            hs.Add(rnd.Next(Asc("a"c), Asc("z"c) + 1)) 'A～Zでランダムに
        End While

        Dim array = hs.Select(Function(i) Chr(i)).ToArray() '毎回Enumerable.ElementAtDafault呼び出すより速い？

        _keys = New DirectionKeys() With {
            .Up = array(0),
            .Down = array(1),
            .Left = array(2),
            .Right = array(3)
        }

        RaiseEvent DirectionKeysChanged(Me, EventArgs.Empty)
    End Sub

    Private _level As Integer
    Public Property Level As Integer
        Get
            Return _level
        End Get
        Set(ByVal value As Integer)
            _level = value
            Const DEFAULT_VALUE As Integer = 5
            EnemySpeed = DEFAULT_VALUE + value
        End Set
    End Property

    Public Property Life As Integer

    Protected Sub DrawInfo(ByVal g As Graphics, ByVal rect As Rectangle)
        TextRenderer.DrawText(g, String.Format("Level：{0} Life：{1}", Level, Life), Target.Font, rect, Target.ForeColor, TextFormatFlags.Top Or TextFormatFlags.Right)
    End Sub

    ''' <summary>
    ''' 敵
    ''' </summary>
    Public Property Enemys As New List(Of Rectangle)

    Public Property EnemySpeed As Integer

    Protected Sub DrawEnemy(ByVal g As Graphics, ByVal rect As Rectangle)
        g.FillEllipse(Brushes.Orange, rect)
    End Sub

    ''' <summary>
    ''' 自分
    ''' </summary>
    Public Property MyRect As Rectangle

    Protected Sub DrawMe(ByVal g As Graphics, ByVal rect As Rectangle)
        g.FillRectangle(Brushes.Red, rect)
    End Sub

    Private receivedCommand As String '"up" "down" "left" "right" のどれか

    Private Sub Target_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If DirectionKeys.Up = e.KeyChar Then
            receivedCommand = "up"
        ElseIf DirectionKeys.Down = e.KeyChar Then
            receivedCommand = "down"
        ElseIf DirectionKeys.Left = e.KeyChar Then
            receivedCommand = "left"
        ElseIf DirectionKeys.Right = e.KeyChar Then
            receivedCommand = "right"
        End If
    End Sub

    Private Sub frameTimer_Elapsed(ByVal sender As Object, ByVal e As Timers.ElapsedEventArgs) Handles frameTimer.Elapsed
        '自分を移動
        Const MOVE_SIZE As Integer = 10
        Dim newRect = MyRect
        Select Case receivedCommand
            Case "up"
                newRect.Offset(0, -MOVE_SIZE)
                If newRect.Y < 0 Then newRect.Y = 0
            Case "down"
                newRect.Offset(0, MOVE_SIZE)
                If newRect.Y > Target.ClientRectangle.Bottom - newRect.Height Then newRect.Y = Target.ClientRectangle.Bottom - newRect.Height
            Case "left"
                newRect.Offset(-MOVE_SIZE, 0)
                If newRect.X < 0 Then newRect.X = 0
            Case "right"
                newRect.Offset(MOVE_SIZE, 0)
                If newRect.X > Target.ClientRectangle.Right - newRect.Width Then newRect.X = Target.ClientRectangle.Right - newRect.Width
        End Select
        MyRect = newRect
        receivedCommand = Nothing

        '敵と当たっていないかチェック
        Dim hiting = Enemys.Where(Function(rect) Not Enumerable.Range(rect.Y, EnemySpeed).All(Function(y) Not MyRect.IntersectsWith(New Rectangle(rect.X, y, rect.Width, rect.Height)))).ToList() 'ToListしないとエラーで終わる
        If hiting.Any() Then
            hiting.ForEach(Sub(item) Enemys.Remove(item))
            Life -= 1
        End If

        '敵の管理
        '移動と削除
        Enemys = Enemys.Select(Function(rect)
                                   rect.Offset(0, EnemySpeed)
                                   Return rect
                               End Function).Where(Function(rect) Target.ClientRectangle.IntersectsWith(rect)).ToList()
        '新規作成
        If rnd.Next(5) = 0 Then '1/5の確率
            Const ENEMY_SIZE As Integer = 20
            Enemys.Add(New Rectangle(rnd.Next(0, Target.ClientRectangle.Right - ENEMY_SIZE), 0, ENEMY_SIZE, ENEMY_SIZE))
        End If

        '描画
        Target.Invalidate()

        'ライフ確認
        If Life <= 0 Then
            'ゲームオーバー
            Me.Stop()
            RaiseEvent GameOver(Me, EventArgs.Empty)
        End If
    End Sub

    Private Sub levelTImer_Elapsed(ByVal sender As Object, ByVal e As Timers.ElapsedEventArgs) Handles levelTimer.Elapsed
        Level += 1
    End Sub

    Private Sub keyChangeTimer_Elapsed(ByVal sender As Object, ByVal e As Timers.ElapsedEventArgs) Handles keyChangeTimer.Elapsed
        CreateAndSetKey()
    End Sub
End Class
