﻿Public Class DirectionKeys
    Public Property Up As Char
    Public Property Down As Char
    Public Property Left As Char
    Public Property Right As Char
End Class
