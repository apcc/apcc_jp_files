﻿Public Class Form1

    Private Sub Form1_Shown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Shown
        MessageBox.Show(My.Resources.StartMessage, "Ready?")
        Dim game As New Game() With {.Target = Me}
        AddHandler game.DirectionKeysChanged,
            Sub(_sender, _e) Me.Invoke(Sub()
                                           Me.Text = String.Format("ぼーらんだー - UP:{0} | DOWN:{1} | LEFT:{2} | RIGHT:{3}",
                                               Char.ToUpper(game.DirectionKeys.Up),
                                               Char.ToUpper(game.DirectionKeys.Down),
                                               Char.ToUpper(game.DirectionKeys.Left),
                                               Char.ToUpper(game.DirectionKeys.Right))
                                           Beep() '音で通知
                                       End Sub)
        AddHandler game.GameOver,
            Sub(_sender, _e) Me.Invoke(Sub()
                                           Me.Text = "ぼーらんだー"
                                           MessageBox.Show(String.Format(My.Resources.GameOverMessage, game.Level), "GAME OVER")
                                           Me.Close()
                                       End Sub)
        game.Start()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
