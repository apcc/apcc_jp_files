*readme.txt著者注*
オリジナルの状態では起動不能だったため、32代会長が修正した上でこのreadme.txtを書いています。
つきましては、作者とreadme.txt著者が別人物であることにご留意ください。

このゲームには、html5とjavascriptが使用されています。
同階層のショートカットから起動できない場合、/data/resources/default_app/index.htmlを直接開いてください。