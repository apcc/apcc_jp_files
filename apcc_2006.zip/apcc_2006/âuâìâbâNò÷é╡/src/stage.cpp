#include "classes.h"
#include <stdio.h>
#include <math.h>


void STAGE::ImportFromFile(char *name, bool DoInit=true)
{
	int i;
	FILE *fp;
	char ch;

	StageInit = 0;
	fp = fopen(name,"r");
	if (fp != NULL)
	{
		StageInit = (fgetc(fp)-'0')*1000;
		StageInit += (fgetc(fp)-'0')*100;
		StageInit += (fgetc(fp)-'0')*10;
		StageInit += (fgetc(fp)-'0');
		for(i=0;i<BLOCK_LENGTH;i++)
		{
			ch = (char)fgetc(fp);
			if('0' <= ch && ch <= '6')
			{
				bl[i].pattern=0;
				bl[i].life=ch-'0';
			}
			else if('A' <= ch && ch <= 'G')
			{
				bl[i].pattern=1;
				bl[i].life = ch-'A' +1;
			}
			else if('a' <= ch && ch <= 'g')
			{
				bl[i].pattern=2;
				bl[i].life = ch-'a' +1;
			}
			else bl[i].life=0;
		}
		fclose(fp);
		if(DoInit) life=3;
		else life += (int)floor((StageInit%100)/10);

	}
}