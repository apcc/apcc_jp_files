//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by script.rc
//
#define IDM_STAGE1                      40001
#define IDM_STAGE2                      40002
#define IDM_STAGE3                      40003
#define IDM_STAGE4                      40004
#define IDM_STAGE5                      40005
#define IDM_PRACTICE_1_1                40006
#define IDM_PRACTICE_1_2                40007
#define IDM_PRACTICE_1_3                40008
#define IDM_PRACTICE_1_4                40009
#define IDM_PRACTICE_1_5                40010
#define IDM_PRACTICE_2_1                40011
#define IDM_PRACTICE_2_2                40012
#define IDM_PRACTICE_2_3                40013
#define IDM_PRACTICE_2_4                40014
#define IDM_PRACTICE_2_5                40015
#define IDM_PRACTICE_3_1                40016
#define IDM_PRACTICE_3_2                40017
#define IDM_PRACTICE_3_3                40018
#define IDM_PRACTICE_3_4                40019
#define IDM_PRACTICE_3_5                40020
#define IDM_PRACTICE_4_1                40021
#define IDM_PRACTICE_4_2                40022
#define IDM_PRACTICE_4_3                40023
#define IDM_PRACTICE_4_4                40024
#define IDM_PRACTICE_4_5                40025
#define IDM_PRACTICE_5_1                40026
#define IDM_PRACTICE_5_2                40027
#define IDM_PRACTICE_5_3                40028
#define IDM_PRACTICE_5_4                40029
#define IDM_PRACTICE_5_5                40030
#define IDM_EXIT                        40031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40032
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
