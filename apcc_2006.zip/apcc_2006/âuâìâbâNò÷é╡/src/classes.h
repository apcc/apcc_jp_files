

#define BLOCK_LENGTH 256
#define BLOCK_COLS 16
class BALL
{
public:
	int x;
	int y;
	int sp_x; // x�������y�̑傫���A�܂�X��
	int sp_y; // ���x
	int level;
	virtual int Create(int);
};

class BLOCK
{
public:
	int life;
	int pattern;
};

class STAGE
{
public:
	BLOCK bl[BLOCK_LENGTH];
	int StageInit;
	int life;
	virtual void ImportFromFile(char*, bool);
	int bar_x;
};



