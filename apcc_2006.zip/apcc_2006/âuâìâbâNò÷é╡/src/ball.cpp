#include "classes.h"
#include <math.h>

int BALL::Create(int stageinit)
{
	level=0;
	sp_x=0-(int)floor(stageinit/1000);
	sp_y=0+(int)floor(stageinit/1000);
	return 0;
}
