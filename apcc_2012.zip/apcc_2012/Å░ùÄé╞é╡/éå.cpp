

#include "DxLib.h"
#include"resource.h"
int Key[256];
int i;
int j;
//int a=544;//2p��
//int b=64;//2p�c
int x[4]={160,480,192,448};//1p 2p 3p 4p ��
int y[4]={64,384,320,256};//1p 2p 3p 4p�@�c
int walk[4]={0,0,0,0};//0 �s�@1�@�� 1p 2p 3p 4p
int muki[4]={0,0,0,0};//1 ��@2�@�E�@3 ���@4�@�� 1p 2p 3p 4p
int houkou[4]={1,1,1,1};//1 ��@2�@�E�@3 ���@4�@�� 1p
int White = GetColor( 255 , 255 , 255 ) ; // ���F�̒l���擾
int time[4]={0,0,0,0};//1p 2p 3p 4p ���Ƃ��n�߂Ă���̎���
int timex[4]={0,0,0,0};//1p 2p 3p 4p�@���Ƃ��Ă���̎���
int timey=0;//�n�܂��Ă���̎���
int timer=0;
int timez[4]={0,0,0,0};//1p 2p 3p 4p ���G���� 
int e=0;
int a=0;
int b=0;
int c=0;
int d=0;
int f=0;
int otosi[4]={0,0,0,0};//1p 2p 3p 4p ���Ƃ��Ă��锻��
int zanki[4]={5,5,5,5};//1p 2p 3p 4p�@�c�@
int cpu[3]={0,0,0};//cpu�̓����@2p 3p 4p 
int oti[4]={0,0,0,0};//�������� 1p 2p 3p 4p 0 �����ĂȂ��@1�������@ 2���G
int start=0; //0�X�^�[�g��� 1�@2p���� 2 1�l�v���C 3 kekka
int map[15][20]={
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
};
int mapa[15][20]={
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
};
int GetHitKeyStateAll_2(int GetHitKeyStateAll_InputKey[]){
    char GetHitKeyStateAll_Key[256];
    GetHitKeyStateAll( GetHitKeyStateAll_Key );
    for(int i=0;i<256;i++){
        if(GetHitKeyStateAll_Key[i]==1) GetHitKeyStateAll_InputKey[i]++;
        else                            GetHitKeyStateAll_InputKey[i]=0;
    }
    return 0;
}
 
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow ){
    ChangeWindowMode(TRUE);//�E�B���h�E���[�h
	SetWindowIconID( IDI_ICON2 ); 
    if(DxLib_Init() == -1 || SetDrawScreen( DX_SCREEN_BACK )!=0) return -1;//�������Ɨ���ʉ�
	 int image1 =  LoadGraph( "block1.bmp" ) ;
	 int image2 =  LoadGraph( "1pue.bmp" ) ;
	 int image3 =  LoadGraph( "1pmigi.bmp" ) ;
	 int image4 =  LoadGraph( "1psita.bmp" ) ;
	 int image5 =  LoadGraph( "1phidari.bmp" ) ;
	 int image6 =  LoadGraph( "block2.bmp" ) ;
	 int image7 =  LoadGraph( "2pue.bmp" ) ;
	 int image8 =  LoadGraph( "2pmigi.bmp" ) ;
	 int image9 =  LoadGraph( "2psita.bmp" ) ;
	 int image10 =  LoadGraph( "2phidari.bmp" ) ;
	 int image11 =  LoadGraph( "block3.bmp" ) ;
	 int image12 =  LoadGraph( "3pue.bmp" ) ;
	 int image13 =  LoadGraph( "3pmigi.bmp" ) ;
	 int image14 =  LoadGraph( "3psita.bmp" ) ;
	 int image15 =  LoadGraph( "3phidari.bmp" ) ;
	 int image16 =  LoadGraph( "block4.bmp" ) ;
	 int image17 =  LoadGraph( "4pue.bmp" ) ;
	 int image18 =  LoadGraph( "4pmigi.bmp" ) ;
	 int image19 =  LoadGraph( "4psita.bmp" ) ;
	 int image20 =  LoadGraph( "4phidari.bmp" ) ;
	 int image21 =  LoadGraph( "block5.bmp" ) ;
	 int image22 =  LoadGraph( "block6.bmp" ) ;
	 int image23 =  LoadGraph( "top.bmp" ) ;
	 int image24 =  LoadGraph( "end1.bmp" ) ;
	 int image25 =  LoadGraph( "end2.bmp" ) ;
	 int image26 =  LoadGraph( "end3.bmp" ) ;
	 int image27 =  LoadGraph( "end4.bmp" ) ;
	 int image28 =  LoadGraph( "setumei.bmp" ) ;
	 int image29 =  LoadGraph( "setumei2.bmp" ) ;
	 while(ProcessMessage()==0 && ClearDrawScreen()==0 && GetHitKeyStateAll_2(Key)==0 && Key[KEY_INPUT_ESCAPE]==0){
          //��ү���ޏ����@  ����ʂ�ر    �@�@�@    �����͏�Ԃ�ۑ��@�@�@�@�@�@�@��ESC��������Ă��Ȃ�
		 if(Key[KEY_INPUT_F7]==1){
			 start=0;
			 e=1;
		 }
		 if(GetNowCount() - time[3]>=3000&&otosi[3]==1){
						otosi[3]=0;
		 }
		 if(GetNowCount() - time[2]>=3000&&otosi[2]==1){
						otosi[2]=0;
		 }
		 if(GetNowCount() - time[1]>=3000&&start==2&&otosi[1]==1){
						otosi[1]=0;
		 }
		 if(GetNowCount()-time[0]>=2000){
			 otosi[0]=0;
		 }
		 if(start==1||start==10){
		 if(GetNowCount()-time[1]>=2000){
			 otosi[1]=0;
		 }
		 }
		 if(start==0){
			 DrawGraph(0 , 0 ,image23 , FALSE  ) ;
			 if(Key[KEY_INPUT_Q]==1){
				 start=1;
				 timey=GetNowCount();
			 }
			 if(Key[KEY_INPUT_S]==1){
				 start=2;
				 timey=GetNowCount();
			 }
			 if(Key[KEY_INPUT_D]==1){
				 start=8;
			 }
			 if(Key[KEY_INPUT_T]==1){
				 x[0]=256;
				 y[0]=160;
				 x[1]=320;
				 y[1]=224;
				 start=10;
			 }
		 }
		 if(start==8){
			 DrawGraph(0 , 0 ,image28 , FALSE  ) ;
			 if(Key[KEY_INPUT_RETURN]==1){
				 start=9;
			 }
		 }
		 if(start==9){
			 DrawGraph(0 , 0 ,image29 , FALSE  ) ;
			 if(Key[KEY_INPUT_S]==1){
				 start=2;
				 timey=GetNowCount();
			 }
			 if(Key[KEY_INPUT_Q]==1){
				 start=1;
				 timey=GetNowCount();
			 }
			 if(Key[KEY_INPUT_T]==1){
				 x[0]=256;
				 y[0]=160;
				 x[1]=320;
				 y[1]=224;
				 start=10;
			 }
		 }
		 if(start==10){
			 for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(mapa[i][j]==1){
					DrawGraph(j*32 , i*32 ,image1 , FALSE  ) ;
				}
				if(mapa[i][j]==2){//1p
					DrawGraph(j*32 , i*32 ,image6 , FALSE  ) ;
					if(GetNowCount() - time[0]>=1000){
						timex[0]=GetNowCount();
						otosi[0]=0;
						mapa[i][j]=3;
					}
				}
				if(mapa[i][j]==3){//1p
					if(GetNowCount() - timex[0]>=1000){
						mapa[i][j]=1;
					}
				}
				if(mapa[i][j]==4){//2p
					DrawGraph(j*32 , i*32 ,image11 , FALSE  ) ;
					if(GetNowCount() - time[1]>=1000){
						timex[1]=GetNowCount();
						mapa[i][j]=5;
					}
					
				}
				if(mapa[i][j]==5){//2p
					if(GetNowCount() - timex[1]>=1000){
						mapa[i][j]=1;
					}
				}
			}
			 }
		 }
		 if(start==1||start==2){
			 if(a==1||b==1||c==1||d==1){
		if(f==0){
		timer=GetNowCount();
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i==2||i==12||i==3||i==11){
					if(j>=5&&j<=15){
					map[i][j]=10;
					}
				}
				if(j==5||j==15||j==6||j==14){
					if(i>=3&&i<=12){
						map[i][j]=10;
					}
				}
			}
		}
		f=1;
		}
	}
			 if(GetNowCount()-timey>=60000){
				 if(f==0){
		timer=GetNowCount();
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i==2||i==12||i==3||i==11){
					if(j>=5&&j<=15){
					map[i][j]=10;
					}
				}
				if(j==5||j==15||j==6||j==14){
					if(i>=3&&i<=12){
						map[i][j]=10;
					}
				}
			}
		}
		f=1;
				 }
	}
	if(GetNowCount()-timey>=120000&&f==1){
		timer=GetNowCount();
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i==5||i==9||i==4||i==10){
					if(j>=7&&j<=13){
					map[i][j]=10;
					}
				}
				if(j==7||j==13||j==8||j==12){
					if(i>=4&&i<=10){
						map[i][j]=10;
					}
				}
			}
		}
		f=3;
	}
	if(f==1){
		if(a==1&&b==1){
			f=2;
		}
		else if(a==1&&c==1){
			f=2;
		}
		else if(a==1&&d==1){
			f=2;
		}
		else if(b==1&&c==1){
			f=2;
		}
		else if(b==1&&d==1){
			f=2;
		}
		else if(c==1&&d==1){
			f=2;
		}
	}
	if(f==2){
		timer=GetNowCount();
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i==5||i==9||i==4||i==10){
					if(j>=7&&j<=13){
					map[i][j]=10;
					}
				}
				if(j==7||j==13||j==8||j==12){
					if(i>=4&&i<=10){
						map[i][j]=10;
					}
				}
			}
		}
		f=3;
	}
			 if(zanki[0]<=0){
			 x[0]=0;
			 y[0]=0;
		 }
		 if(zanki[1]<=0){
			 x[1]=0;
			 y[1]=0;
		 }
		 if(zanki[2]<=0){
			 x[2]=0;
			 y[2]=0;
		 }
		 if(zanki[3]<=0){
			 x[3]=0;
			 y[3]=0;
		 }
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(map[i][j]==1){
					DrawGraph(j*32 , i*32 ,image1 , FALSE  ) ;
				}
				if(map[i][j]==2){//1p
					DrawGraph(j*32 , i*32 ,image6 , FALSE  ) ;
					if(GetNowCount() - time[0]>=1000){
						timex[0]=GetNowCount();
						otosi[0]=0;
						map[i][j]=3;
					}
				}
				if(map[i][j]==3){//1p
					if(GetNowCount() - timex[0]>=1000){
						map[i][j]=1;
					}
				}
				if(map[i][j]==4){//2p
					DrawGraph(j*32 , i*32 ,image11 , FALSE  ) ;
					if(GetNowCount() - time[1]>=1000){
						timex[1]=GetNowCount();
						map[i][j]=5;
					}
					
				}
				if(map[i][j]==5){//2p
					if(GetNowCount() - timex[1]>=1000){
						map[i][j]=1;
					}
				}
				if(map[i][j]==6){//3p
					DrawGraph(j*32 , i*32 ,image16 , FALSE  ) ;
					if(GetNowCount() - time[2]>=1000){
						timex[2]=GetNowCount();
						map[i][j]=7;
					}
				}
				if(map[i][j]==7){//3p
					if(GetNowCount() - timex[2]>=1000){
						map[i][j]=1;
					}
				}
				if(map[i][j]==8){//4p
					DrawGraph(j*32 , i*32 ,image21 , FALSE  ) ;
					if(GetNowCount() - time[3]>=1000){
						timex[3]=GetNowCount();
						map[i][j]=9;
					}
				}
				if(map[i][j]==9){//4p
					if(GetNowCount() - timex[3]>=1000){
						map[i][j]=1;
					}
				}
				if(map[i][j]==10){
					DrawGraph(j*32 , i*32 ,image22 , FALSE  ) ;
					if(GetNowCount() - timer>=3000){
						map[i][j]=0;
					}
				}
			}
		}
		}
		//1p��������
		if(start==10){
			if(zanki[0]>0){
		if(x[0]%32==0&&y[0]%32==0){
			if(otosi[0]!=1&&oti[0]==0){
			muki[0]=0;
			walk[0]=1;
			if(Key[ KEY_INPUT_UP   ]>=1 ){
				houkou[0]=1;
				if(Key[ KEY_INPUT_M  ]<1){
								if(mapa[y[0]/32-1][x[0]/32]!=0&&mapa[y[0]/32-1][x[0]/32]!=3&&mapa[y[0]/32-1][x[0]/32]!=5&&mapa[y[0]/32-1][x[0]/32]!=7&&mapa[y[0]/32-1][x[0]/32]!=9){
									muki[0]=1;
								}
				}
			}
			else if(Key[ KEY_INPUT_RIGHT   ]>=1 ){
				houkou[0]=2;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[0]/32][x[0]/32+1]!=0&&mapa[y[0]/32][x[0]/32+1]!=3&&mapa[y[0]/32][x[0]/32+1]!=5&&mapa[y[0]/32][x[0]/32+1]!=7&&mapa[y[0]/32][x[0]/32+1]!=9){
									muki[0]=2;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_DOWN   ]>=1 ){
				houkou[0]=3;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[0]/32+1][x[0]/32]!=0&&mapa[y[0]/32+1][x[0]/32]!=3&&mapa[y[0]/32+1][x[0]/32]!=5&&mapa[y[0]/32+1][x[0]/32]!=7&&mapa[y[0]/32+1][x[0]/32]!=9){
									muki[0]=3;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_LEFT   ]>=1 ){
				houkou[0]=4;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[0]/32][x[0]/32-1]!=0&&mapa[y[0]/32][x[0]/32-1]!=3&&mapa[y[0]/32][x[0]/32-1]!=5&&mapa[y[0]/32][x[0]/32-1]!=7&&mapa[y[0]/32][x[0]/32-1]!=9){
									muki[0]=4;
								}
							}
							}
				}
			}
			else {
				walk[0]=0;
			}
			}
		}
		if(walk[0]==0){
					if(Key[ KEY_INPUT_RETURN   ]==1&&otosi[0]!=1){
						time[0] = GetNowCount();
						if(houkou[0]==1){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[0]>i*32&&mapa[i][x[0]/32]==1){
									mapa[i][x[0]/32]=2;
								}
							}
							}
						}
						else if(houkou[0]==2){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[0]<j*32&&mapa[y[0]/32][j]==1){
									mapa[y[0]/32][j]=2;
								}
							}
							}
						}
						else if(houkou[0]==3){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[0]<i*32&&mapa[i][x[0]/32]==1){
									mapa[i][x[0]/32]=2;
								}
							}
							}
						}
						else if(houkou[0]==4){
							for(i=0;i<15;i++){
								for(j=0;j<20;j++){
								if(x[0]>j*32&&mapa[y[0]/32][j]==1){
									mapa[y[0]/32][j]=2;
								}
							}
							}
						}
						otosi[0]=1;
					}
				}
		if(walk[0]==1){
		if(muki[0]==1){
			y[0]--;
		}
		if(muki[0]==2){
			x[0]++;
		}
		if(muki[0]==3){
			y[0]++;
		}
		if(muki[0]==4){
			x[0]--;
		}
		}
		if(mapa[y[0]/32][x[0]/32]==5&&oti[0]==0){
			oti[0]=1;
		}
		else if(oti[0]==0&&mapa[y[0]/32][x[0]/32]==7){
			oti[0]=1;
		}
		else if(oti[0]==0&&mapa[y[0]/32][x[0]/32]==9){
			oti[0]=1;
		}
		else if(oti[0]==0&&mapa[y[0]/32][x[0]/32]==0){
			oti[0]=1;
		}
		if(oti[0]==1){
			zanki[0]--;
			walk[0]=0;
			x[0]=x[0]/32*32;
			y[0]=y[0]/32*32;
			timez[0]=GetNowCount();
			oti[0]=2;
		}
		if(GetNowCount()-timez[0]>=1000){
			oti[0]=0;
			timez[0]=0;
		}
		}
		}
		if(start==1||start==2){
		if(zanki[0]>0){
		if(x[0]%32==0&&y[0]%32==0){
			if(otosi[0]!=1&&oti[0]==0){
			muki[0]=0;
			walk[0]=1;
			if(Key[ KEY_INPUT_UP   ]>=1 ){
				houkou[0]=1;
				if(Key[ KEY_INPUT_M  ]<1){
								if(map[y[0]/32-1][x[0]/32]!=0&&map[y[0]/32-1][x[0]/32]!=3&&map[y[0]/32-1][x[0]/32]!=5&&map[y[0]/32-1][x[0]/32]!=7&&map[y[0]/32-1][x[0]/32]!=9){
									muki[0]=1;
								}
				}
			}
			else if(Key[ KEY_INPUT_RIGHT   ]>=1 ){
				houkou[0]=2;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[0]/32][x[0]/32+1]!=0&&map[y[0]/32][x[0]/32+1]!=3&&map[y[0]/32][x[0]/32+1]!=5&&map[y[0]/32][x[0]/32+1]!=7&&map[y[0]/32][x[0]/32+1]!=9){
									muki[0]=2;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_DOWN   ]>=1 ){
				houkou[0]=3;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[0]/32+1][x[0]/32]!=0&&map[y[0]/32+1][x[0]/32]!=3&&map[y[0]/32+1][x[0]/32]!=5&&map[y[0]/32+1][x[0]/32]!=7&&map[y[0]/32+1][x[0]/32]!=9){
									muki[0]=3;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_LEFT   ]>=1 ){
				houkou[0]=4;
				if(Key[ KEY_INPUT_M  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[0]/32][x[0]/32-1]!=0&&map[y[0]/32][x[0]/32-1]!=3&&map[y[0]/32][x[0]/32-1]!=5&&map[y[0]/32][x[0]/32-1]!=7&&map[y[0]/32][x[0]/32-1]!=9){
									muki[0]=4;
								}
							}
							}
				}
			}
			else {
				walk[0]=0;
			}
			}
		}
		if(walk[0]==0){
					if(Key[ KEY_INPUT_RETURN   ]==1&&otosi[0]!=1){
						time[0] = GetNowCount();
						if(houkou[0]==1){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[0]>i*32&&map[i][x[0]/32]==1){
									map[i][x[0]/32]=2;
								}
							}
							}
						}
						else if(houkou[0]==2){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[0]<j*32&&map[y[0]/32][j]==1){
									map[y[0]/32][j]=2;
								}
							}
							}
						}
						else if(houkou[0]==3){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[0]<i*32&&map[i][x[0]/32]==1){
									map[i][x[0]/32]=2;
								}
							}
							}
						}
						else if(houkou[0]==4){
							for(i=0;i<15;i++){
								for(j=0;j<20;j++){
								if(x[0]>j*32&&map[y[0]/32][j]==1){
									map[y[0]/32][j]=2;
								}
							}
							}
						}
						otosi[0]=1;
					}
				}
		if(walk[0]==1){
		if(muki[0]==1){
			y[0]--;
		}
		if(muki[0]==2){
			x[0]++;
		}
		if(muki[0]==3){
			y[0]++;
		}
		if(muki[0]==4){
			x[0]--;
		}
		}
		if(map[y[0]/32][x[0]/32]==5&&oti[0]==0){
			oti[0]=1;
		}
		else if(oti[0]==0&&map[y[0]/32][x[0]/32]==7){
			oti[0]=1;
		}
		else if(oti[0]==0&&map[y[0]/32][x[0]/32]==9){
			oti[0]=1;
		}
		else if(oti[0]==0&&map[y[0]/32][x[0]/32]==0){
			oti[0]=1;
		}
		if(oti[0]==1){
			zanki[0]--;
			walk[0]=0;
			x[0]=x[0]/32*32;
			y[0]=y[0]/32*32;
			if(map[y[0]/32][x[0]/32]==0){
				if(f==1){
					x[0]=224;
					y[0]=128;
				}
				if(f==3){
					x[0]=288;
					y[0]=192;
				}
			}
			timez[0]=GetNowCount();
			oti[0]=2;
		}
		if(GetNowCount()-timez[0]>=1000){
			oti[0]=0;
			timez[0]=0;
		}
		}
		}//1p�����܂�
		//2p��������
		if(start==10){
			if(zanki[1]>=0){
		if(x[1]%32==0&&y[1]%32==0){
			if(otosi[1]!=1&&oti[1]==0){
			muki[1]=0;
			walk[1]=1;
			if(Key[ KEY_INPUT_W   ]>=1 ){
				houkou[1]=1;
				if(Key[ KEY_INPUT_C  ]<1){
								if(mapa[y[1]/32-1][x[1]/32]!=0&&mapa[y[1]/32-1][x[1]/32]!=3&&mapa[y[1]/32-1][x[1]/32]!=5&&mapa[y[1]/32-1][x[1]/32]!=7&&mapa[y[1]/32+1][x[1]/32]!=9){
									muki[1]=1;
								}
				}
			}
			else if(Key[ KEY_INPUT_D   ]>=1 ){
				houkou[1]=2;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[1]/32][x[1]/32+1]!=0&&mapa[y[1]/32][x[1]/32+1]!=3&&mapa[y[1]/32][x[1]/32+1]!=5&&mapa[y[1]/32][x[1]/32+1]!=7&&mapa[y[1]/32+1][x[1]/32]!=9){
									muki[1]=2;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_S   ]>=1 ){
				houkou[1]=3;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[1]/32+1][x[1]/32]!=0&&mapa[y[1]/32+1][x[1]/32]!=3&&mapa[y[1]/32+1][x[1]/32]!=5&&mapa[y[1]/32+1][x[1]/32]!=7&&mapa[y[1]/32+1][x[1]/32]!=9){
									muki[1]=3;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_A   ]>=1 ){
				houkou[1]=4;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(mapa[y[1]/32][x[1]/32-1]!=0&&mapa[y[1]/32][x[1]/32-1]!=3&&mapa[y[1]/32][x[1]/32-1]!=5&&mapa[y[1]/32][x[1]/32-1]!=7&&mapa[y[1]/32][x[1]/32-1]!=9){
									muki[1]=4;
								}
							}
							}
				}
			}
			else {
				walk[1]=0;
			}
			}
		}
		if(walk[1]==0){
					if(Key[ KEY_INPUT_Z   ]==1){
						time[1] = GetNowCount();
						otosi[1]=1;
						if(houkou[1]==1){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]>i*32&&mapa[i][x[1]/32]==1){
									mapa[i][x[1]/32]=4;
								}
							}
							}
						}
						else if(houkou[1]==2){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]<j*32&&mapa[y[1]/32][j]==1){
									mapa[y[1]/32][j]=4;
								}
							}
							}
						}
						else if(houkou[1]==3){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]<i*32&&mapa[i][x[1]/32]==1){
									mapa[i][x[1]/32]=4;
								}
							}
							}
						}
						else if(houkou[1]==4){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]>j*32&&mapa[y[1]/32][j]==1){
									mapa[y[1]/32][j]=4;
								}
							}
							}
						}
					}
				}
		if(walk[1]==1){
		if(muki[1]==1){
			y[1]--;
		}
		if(muki[1]==2){
			x[1]++;
		}
		if(muki[1]==3){
			y[1]++;
		}
		if(muki[1]==4){
			x[1]--;
		}
		}
		if(mapa[y[1]/32][x[1]/32]==3&&oti[1]==0){
			oti[1]=1;
		}
		else if(oti[1]==0&&mapa[y[1]/32][x[1]/32]==7){
			oti[1]=1;
		}
		else if(oti[1]==0&&mapa[y[1]/32][x[1]/32]==9){
			oti[1]=1;
		}
		else if(oti[1]==0&&mapa[y[1]/32][x[1]/32]==0){
			oti[1]=1;
		}
		if(oti[1]==1){
			zanki[1]--;
			timez[1]=GetNowCount();
			walk[1]=0;
			x[1]=x[1]/32*32;
			y[1]=y[1]/32*32;
			oti[1]=2;
		}
		if(GetNowCount()-timez[1]>=1000){
			oti[1]=0;
			timez[1]=0;
		}
		}
		}
		if(start==1){
			if(zanki[1]>=0){
		if(x[1]%32==0&&y[1]%32==0){
			if(otosi[1]!=1&&oti[1]==0){
			muki[1]=0;
			walk[1]=1;
			if(Key[ KEY_INPUT_W   ]>=1 ){
				houkou[1]=1;
				if(Key[ KEY_INPUT_C  ]<1){
								if(map[y[1]/32-1][x[1]/32]!=0&&map[y[1]/32-1][x[1]/32]!=3&&map[y[1]/32-1][x[1]/32]!=5&&map[y[1]/32-1][x[1]/32]!=7&&map[y[1]/32+1][x[1]/32]!=9){
									muki[1]=1;
								}
				}
			}
			else if(Key[ KEY_INPUT_D   ]>=1 ){
				houkou[1]=2;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[1]/32][x[1]/32+1]!=0&&map[y[1]/32][x[1]/32+1]!=3&&map[y[1]/32][x[1]/32+1]!=5&&map[y[1]/32][x[1]/32+1]!=7&&map[y[1]/32+1][x[1]/32]!=9){
									muki[1]=2;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_S   ]>=1 ){
				houkou[1]=3;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[1]/32+1][x[1]/32]!=0&&map[y[1]/32+1][x[1]/32]!=3&&map[y[1]/32+1][x[1]/32]!=5&&map[y[1]/32+1][x[1]/32]!=7&&map[y[1]/32+1][x[1]/32]!=9){
									muki[1]=3;
								}
							}
							}
				}
			}
			else if(Key[ KEY_INPUT_A   ]>=1 ){
				houkou[1]=4;
				if(Key[ KEY_INPUT_C  ]<1){
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(map[y[1]/32][x[1]/32-1]!=0&&map[y[1]/32][x[1]/32-1]!=3&&map[y[1]/32][x[1]/32-1]!=5&&map[y[1]/32][x[1]/32-1]!=7&&map[y[1]/32][x[1]/32-1]!=9){
									muki[1]=4;
								}
							}
							}
				}
			}
			else {
				walk[1]=0;
			}
			}
		}
		if(walk[1]==0){
					if(Key[ KEY_INPUT_Z   ]==1){
						time[1] = GetNowCount();
						otosi[1]=1;
						if(houkou[1]==1){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]>i*32&&map[i][x[1]/32]==1){
									map[i][x[1]/32]=4;
								}
							}
							}
						}
						else if(houkou[1]==2){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]<j*32&&map[y[1]/32][j]==1){
									map[y[1]/32][j]=4;
								}
							}
							}
						}
						else if(houkou[1]==3){
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]<i*32&&map[i][x[1]/32]==1){
									map[i][x[1]/32]=4;
								}
							}
							}
						}
						else if(houkou[1]==4){
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]>j*32&&map[y[1]/32][j]==1){
									map[y[1]/32][j]=4;
								}
							}
							}
						}
					}
				}
		if(walk[1]==1){
		if(muki[1]==1){
			y[1]--;
		}
		if(muki[1]==2){
			x[1]++;
		}
		if(muki[1]==3){
			y[1]++;
		}
		if(muki[1]==4){
			x[1]--;
		}
		}
		if(map[y[1]/32][x[1]/32]==3&&oti[1]==0){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==7){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==9){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==0){
			oti[1]=1;
		}
		if(oti[1]==1){
			zanki[1]--;
			timez[1]=GetNowCount();
			walk[1]=0;
			x[1]=x[1]/32*32;
			y[1]=y[1]/32*32;
			if(map[y[1]/32][x[1]/32]==0){
				if(f==1){
					x[1]=416;
					y[1]=128;
				}
				if(f==3){
					x[1]=352;
					y[1]=192;
				}
			}
			oti[1]=2;
		}
		if(GetNowCount()-timez[1]>=1000){
			oti[1]=0;
			timez[1]=0;
		}
		}
		}///2p�����܂�
		//2p(cpu)
		if(zanki[1]>0&&start==2){
		if(x[1]%32==0&&y[1]%32==0){
			if(otosi[1]!=1){
			if(x[0]/32==x[1]/32&&y[0]/32<y[1]/32){
					houkou[1]=1;
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]>i*32&&map[i][x[1]/32]==1){
									map[i][x[1]/32]=4;
								}
							}
							}
							time[1] = GetNowCount();
							otosi[1]=1;
			}
			else if(y[0]/32==y[1]/32&&x[0]/32>x[1]/32){
					houkou[1]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]<j*32&&map[y[1]/32][j]==1){
									map[y[1]/32][j]=4;
								}
							}
							}
							time[1] = GetNowCount();
							otosi[1]=1;
			}
			else if(x[0]/32==x[1]/32&&y[0]/32>y[1]/32){
					houkou[1]=3;
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[1]<i*32&&map[i][x[1]/32]==1){
									map[i][x[1]/32]=4;
								}
							}
							}
							time[1] = GetNowCount();
							otosi[1]=1;
			}
			else if(y[0]/32==y[1]/32&&x[0]/32<x[1]/32){
					houkou[1]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[1]>j*32&&map[y[1]/32][j]==1){
									map[y[1]/32][j]=4;
								}
							}
							}
							time[1] = GetNowCount();
							otosi[1]=1;
			}
			if(otosi[1]!=1&&oti[1]==0){
			muki[1]=0;
			walk[1]=1;
			cpu[0]=GetRand(3);
			if(cpu[0]==0 ){
				houkou[1]=1;
				if(map[y[1]/32-1][x[1]/32]!=0&&map[y[1]/32-1][x[1]/32]!=3&&map[y[1]/32-1][x[1]/32]!=5&&map[y[1]/32-1][x[1]/32]!=7&&map[y[1]/32-1][x[1]/32]!=9){
									muki[1]=1;
								}
			}
			if(cpu[0]==1){
				houkou[1]=2;
				if(map[y[1]/32][x[1]/32+1]!=0&&map[y[1]/32][x[1]/32+1]!=3&&map[y[1]/32][x[1]/32+1]!=5&&map[y[1]/32][x[1]/32+1]!=7&&map[y[1]/32][x[1]/32+1]!=9){
									muki[1]=2;
								}
			}
			if(cpu[0]==2  ){
				houkou[1]=3;
				if(map[y[1]/32+1][x[1]/32]!=0&&map[y[1]/32+1][x[1]/32]!=3&&map[y[1]/32+1][x[1]/32]!=5&&map[y[1]/32+1][x[1]/32]!=7&&map[y[1]/32+1][x[1]/32]!=9){
									muki[1]=3;
								}
			}
			if(cpu[0]==3){
				houkou[1]=4;
				if(map[y[1]/32][x[1]/32-1]!=0&&map[y[1]/32][x[1]/32-1]!=3&&map[y[1]/32][x[1]/32-1]!=5&&map[y[1]/32][x[1]/32-1]!=7&&map[y[1]/32][x[1]/32-1]!=9){
									muki[1]=4;
								}
			}
			}
			}
		}
		
		if(walk[1]==1&&otosi[1]!=1){
		if(muki[1]==1){
			y[1]--;
		}
		if(muki[1]==2){
			x[1]++;
		}
		if(muki[1]==3){
			y[1]++;
		}
		if(muki[1]==4){
			x[1]--;
		}
		}
		if(map[y[1]/32][x[1]/32]==3&&oti[1]==0){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==7){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==9){
			oti[1]=1;
		}
		else if(oti[1]==0&&map[y[1]/32][x[1]/32]==0){
			oti[1]=1;
		}
		if(oti[1]==1){
			zanki[1]--;
			walk[1]=0;
			x[1]=x[1]/32*32;
			y[1]=y[1]/32*32;
			if(map[y[1]/32][x[1]/32]==0){
				if(f==1){
					x[1]=416;
					y[1]=128;
				}
				if(f==3){
					x[1]=352;
					y[1]=192;
				}
			}
			timez[1]=GetNowCount();
			oti[1]=2;
		}
		if(GetNowCount()-timez[1]>=1000){
			oti[1]=0;
			timez[1]=0;
		}
		}
		//2p(cpu)�����܂�
		//3p
		if((zanki[2]>0&&start==1)||(zanki[2]>0&&start==2)){
		if(x[2]%32==0&&y[2]%32==0){
			if(otosi[2]!=1){
				if(start==1){
			if(x[0]/32==x[2]/32&&y[0]/32<y[2]/32){
					houkou[2]=1;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]>i*32&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[0]/32==y[2]/32&&x[0]/32>x[2]/32){
					houkou[2]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]<j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(x[0]/32==x[2]/32&&y[0]/32>y[2]/32){
					houkou[2]=3;
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]<i*32&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[0]/32==y[2]/32&&x[0]/32<x[2]/32){
					houkou[2]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]>j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(x[1]/32==x[2]/32&&y[1]/32<y[2]/32){
					houkou[2]=1;
					for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]>(i*32)&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[1]/32==y[2]/32&&x[1]/32>x[2]/32){
					houkou[2]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]<j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(x[1]/32==x[2]/32&&y[1]/32>y[2]/32){
					houkou[2]=3;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]<i*32&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=8;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[1]/32==y[2]/32&&x[1]/32<x[2]/32){
					houkou[2]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]>j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
				}
			if(start==2){
				if(x[0]/32==x[2]/32&&y[0]/32<y[2]/32){
					houkou[2]=1;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]>i*32&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[0]/32==y[2]/32&&x[0]/32>x[2]/32){
					houkou[2]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]<j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(x[0]/32==x[2]/32&&y[0]/32>y[2]/32){
					houkou[2]=3;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[2]<i*32&&map[i][x[2]/32]==1){
									map[i][x[2]/32]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			else if(y[0]/32==y[2]/32&&x[0]/32<x[2]/32){
					houkou[2]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[2]>j*32&&map[y[2]/32][j]==1){
									map[y[2]/32][j]=6;
								}
							}
							}
							time[2] = GetNowCount();
							otosi[2]=1;
			}
			}
			if(otosi[2]!=1&&oti[2]==0){
			muki[2]=0;
			walk[2]=1;
			cpu[1]=GetRand(3);
			if(cpu[1]==0 ){
				houkou[2]=1;
				if(map[y[2]/32-1][x[2]/32]!=0&&map[y[2]/32-1][x[2]/32]!=3&&map[y[2]/32-1][x[2]/32]!=5&&map[y[2]/32-1][x[2]/32]!=7&&map[y[2]/32-1][x[2]/32]!=9){
									muki[2]=1;
								}
			}
			if(cpu[1]==1){
				houkou[2]=2;
				if(map[y[2]/32][x[2]/32+1]!=0&&map[y[2]/32][x[2]/32+1]!=3&&map[y[2]/32][x[2]/32+1]!=5&&map[y[2]/32][x[2]/32+1]!=7&&map[y[2]/32][x[2]/32+1]!=9){
									muki[2]=2;
								}
			}
			if(cpu[1]==2  ){
				houkou[2]=3;
				if(map[y[2]/32+1][x[2]/32]!=0&&map[y[2]/32+1][x[2]/32]!=3&&map[y[2]/32+1][x[2]/32]!=5&&map[y[2]/32+1][x[2]/32]!=7&&map[y[2]/32+1][x[2]/32]!=9){
									muki[2]=3;
								}
			}
			if(cpu[1]==3){
				houkou[2]=4;
				if(map[y[2]/32][x[2]/32-1]!=0&&map[y[2]/32][x[2]/32-1]!=3&&map[y[2]/32][x[2]/32-1]!=5&&map[y[2]/32][x[2]/32-1]!=7&&map[y[2]/32][x[2]/32-1]!=9){
									muki[2]=4;
								}
			}
			}
			}
		}
		
		if(walk[2]==1&&otosi[2]!=1){
		if(muki[2]==1){
			y[2]--;
		}
		if(muki[2]==2){
			x[2]++;
		}
		if(muki[2]==3){
			y[2]++;
		}
		if(muki[2]==4){
			x[2]--;
		}
		}
		if(map[y[2]/32][x[2]/32]==3&&oti[2]==0){
			oti[2]=1;
		}
		else if(oti[2]==0&&map[y[2]/32][x[2]/32]==5){
			oti[2]=1;
		}
		else if(oti[2]==0&&map[y[2]/32][x[2]/32]==9){
			oti[2]=1;
		}
		else if(oti[2]==0&&map[y[2]/32][x[2]/32]==0){
			oti[2]=1;
		}
		if(oti[2]==1){
			zanki[2]--;
			walk[2]=0;
			x[2]=x[2]/32*32;
			y[2]=y[2]/32*32;
			if(map[y[2]/32][x[2]/32]==0){
				if(f==1){
					x[2]=224;
					y[2]=320;
				}
				if(f==3){
					x[2]=288;
					y[2]=256;
				}
			}
			timez[2]=GetNowCount();
			oti[2]=2;
		}
		if(GetNowCount()-timez[2]>=1000){
			oti[2]=0;
			timez[2]=0;
		}
		}
		//3p(cpu)�����܂�
		//4p(cpu)
		if((zanki[3]>0&&start==1)||(zanki[3]>0&&start==2)){
		if(x[3]%32==0&&y[3]%32==0){
			if(otosi[3]!=1){
				if(start==1){
			if(x[1]/32==x[3]/32&&y[1]/32<y[3]/32){
					houkou[3]=1;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]>i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[1]/32==y[3]/32&&x[1]/32>x[3]/32){
					houkou[3]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]<j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(x[1]/32==x[3]/32&&y[1]/32>y[3]/32){
					houkou[3]=3;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]<i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[1]/32==y[3]/32&&x[1]/32<x[3]/32){
					houkou[3]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]>j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(x[0]/32==x[3]/32&&y[0]/32<y[3]/32){
					houkou[3]=1;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]>i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[0]/32==y[3]/32&&x[0]/32>x[3]/32){
					houkou[3]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]<j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(x[0]/32==x[3]/32&&y[0]/32>y[3]/32){
					houkou[3]=3;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]<i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[0]/32==y[3]/32&&x[0]/32<x[3]/32){
					houkou[3]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]>j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			}
			if(start==2){
				if(x[0]/32==x[3]/32&&y[0]/32<y[3]/32){
					houkou[3]=1;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]>i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[0]/32==y[3]/32&&x[0]/32>x[3]/32){
					houkou[3]=2;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]<j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(x[0]/32==x[3]/32&&y[0]/32>y[3]/32){
					houkou[3]=3;
							for(j=0;j<20;j++){
							for(i=0;i<15;i++){
								if(y[3]<i*32&&map[i][x[3]/32]==1){
									map[i][x[3]/32]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			else if(y[0]/32==y[3]/32&&x[0]/32<x[3]/32){
					houkou[3]=4;
							for(i=0;i<15;i++){
							for(j=0;j<20;j++){
								if(x[3]>j*32&&map[y[3]/32][j]==1){
									map[y[3]/32][j]=8;
								}
							}
							}
							time[3] = GetNowCount();
							otosi[3]=1;
			}
			}
			if(otosi[3]!=1&&oti[3]==0){
			muki[3]=0;
			walk[3]=1;
			cpu[2]=GetRand(3);
			if(cpu[2]==0 ){
				houkou[3]=1;
								if(map[y[3]/32-1][x[3]/32]!=0&&map[y[3]/32-1][x[3]/32]!=3&&map[y[3]/32-1][x[3]/32]!=5&&map[y[3]/32-1][x[3]/32]!=7&&map[y[3]/32-1][x[3]/32]!=9){
									muki[3]=1;
								}
			}
			if(cpu[2]==1){
				houkou[3]=2;
								if(map[y[3]/32][x[3]/32+1]!=0&&map[y[3]/32][x[3]/32+1]!=3&&map[y[3]/32][x[3]/32+1]!=5&&map[y[3]/32][x[3]/32+1]!=7&&map[y[3]/32][x[3]/32+1]!=9){
									muki[3]=2;
								}
			}
			if(cpu[2]==2  ){
				houkou[3]=3;
								if(map[y[3]/32+1][x[3]/32]!=0&&map[y[3]/32+1][x[3]/32]!=3&&map[y[3]/32+1][x[3]/32]!=5&&map[y[3]/32+1][x[3]/32]!=7&&map[y[3]/32+1][x[3]/32]!=9){
									muki[3]=3;
								}
			}
			if(cpu[2]==3){
				houkou[3]=4;
								if(map[y[3]/32][x[3]/32-1]!=0&&map[y[3]/32][x[3]/32-1]!=3&&map[y[3]/32][x[3]/32-1]!=5&&map[y[3]/32][x[3]/32-1]!=7&&map[y[3]/32][x[3]/32-1]!=9){
									muki[3]=4;
								}
			}
			}
			}
		}
		
		if(walk[3]==1&&otosi[3]!=1){
		if(muki[3]==1){
			y[3]--;
		}
		if(muki[3]==2){
			x[3]++;
		}
		if(muki[3]==3){
			y[3]++;
		}
		if(muki[3]==4){
			x[3]--;
		}
		}
		if(map[y[3]/32][x[3]/32]==3&&oti[3]==0){
			oti[3]=1;
		}
		else if(oti[3]==0&&map[y[3]/32][x[3]/32]==5){
			oti[3]=1;
		}
		else if(oti[3]==0&&map[y[3]/32][x[3]/32]==7){
			oti[3]=1;
		}
		else if(oti[3]==0&&map[y[3]/32][x[3]/32]==0){
			oti[3]=1;
		}
		if(oti[3]==1){
			zanki[3]--;
			walk[3]=0;
			x[3]=x[3]/32*32;
			y[3]=y[3]/32*32;
			if(map[y[3]/32][x[3]/32]==0){
				if(f==1){
					x[3]=416;
					y[3]=320;
				}
				if(f==3){
					x[3]=352;
					y[3]=256;
				}
			}
			timez[3]=GetNowCount();
			oti[3]=2;
		}
		if(GetNowCount()-timez[3]>=1000){
			oti[3]=0;
			timez[3]=0;
		}
		}//4p(cpu)
		if(start==10){
			if(zanki[0]<=0){
			a=1;
			start=4;
		}
		if(zanki[1]<=0){
			b=1;
			start=5;
		}
		if(zanki[0]>0){
	if(houkou[0]==1){
		DrawGraph( x[0] , y[0] ,image2 , TRUE  ) ;
	}
	else if(houkou[0]==2){
		DrawGraph( x[0] , y[0] ,image3 , TRUE  ) ;
	}
	else if(houkou[0]==3){
		DrawGraph( x[0] , y[0] ,image4 , TRUE  ) ;
	}
	else if(houkou[0]==4){
		DrawGraph( x[0] , y[0] ,image5 , TRUE  ) ;
	}
		}
		if(zanki[1]>0){
			if(houkou[1]==1){
		DrawGraph( x[1] , y[1] ,image7 , TRUE  ) ;
	}
	else if(houkou[1]==2){
		DrawGraph( x[1] , y[1] ,image8 , TRUE  ) ;
	}
	else if(houkou[1]==3){
		DrawGraph( x[1] , y[1] ,image9 , TRUE  ) ;
	}
	else if(houkou[1]==4){
		DrawGraph( x[1] , y[1] ,image10 , TRUE  ) ;
	}
		}
		DrawFormatString(0,0, White , "1p%d��"        , zanki[0]);
	DrawFormatString(0,160, White , "2p%d��"        , zanki[1]);
		}
		if(start==1||start==2){
		if(zanki[0]<=0){
			a=1;
		}
		if(zanki[1]<=0){
			b=1;
		}
		if(zanki[2]<=0){
			c=1;
		}
		if(zanki[3]<=0){
			d=1;
		}
		if(start==1){
		if(a==1&&b==1){
			start=3;
		}
		if(a==1&&c==1&&d==1){
			start=4;
		}
		if(b==1&&c==1&&d==1){
			start=5;
		}
		}
		if(start==2){
			if(a==1){
				start=6;
			}
			if(b==1&&c==1&&d==1){
				start=7;
			}
		}
		if(zanki[0]>0){
	if(houkou[0]==1){
		DrawGraph( x[0] , y[0] ,image2 , TRUE  ) ;
	}
	else if(houkou[0]==2){
		DrawGraph( x[0] , y[0] ,image3 , TRUE  ) ;
	}
	else if(houkou[0]==3){
		DrawGraph( x[0] , y[0] ,image4 , TRUE  ) ;
	}
	else if(houkou[0]==4){
		DrawGraph( x[0] , y[0] ,image5 , TRUE  ) ;
	}
		}
		if(zanki[1]>0){
			if(houkou[1]==1){
		DrawGraph( x[1] , y[1] ,image7 , TRUE  ) ;
	}
	else if(houkou[1]==2){
		DrawGraph( x[1] , y[1] ,image8 , TRUE  ) ;
	}
	else if(houkou[1]==3){
		DrawGraph( x[1] , y[1] ,image9 , TRUE  ) ;
	}
	else if(houkou[1]==4){
		DrawGraph( x[1] , y[1] ,image10 , TRUE  ) ;
	}
		}
		if(zanki[2]>0){
			if(houkou[2]==1){
		DrawGraph( x[2] , y[2] ,image12 , TRUE  ) ;
	}
	else if(houkou[2]==2){
		DrawGraph( x[2] , y[2] ,image13 , TRUE  ) ;
	}
	else if(houkou[2]==3){
		DrawGraph( x[2] , y[2] ,image14 , TRUE  ) ;
	}
	else if(houkou[2]==4){
		DrawGraph( x[2] , y[2] ,image15 , TRUE  ) ;
	}
		}
		if(zanki[3]>0){
			if(houkou[3]==1){
		DrawGraph( x[3] , y[3] ,image17 , TRUE  ) ;
	}
	else if(houkou[3]==2){
		DrawGraph( x[3] , y[3] ,image18 , TRUE  ) ;
	}
	else if(houkou[3]==3){
		DrawGraph( x[3] , y[3] ,image19 , TRUE  ) ;
	}
	else if(houkou[3]==4){
		DrawGraph( x[3] , y[3] ,image20 , TRUE  ) ;
	}
		}
	DrawFormatString(0,0, White , "1p%d��"        , zanki[0]);
	DrawFormatString(0,160, White , "2p%d��"        , zanki[1]);
	DrawFormatString(0,320, White , "3p%d��"        , zanki[2]);
	DrawFormatString(0,416, White , "4p%d��"        , zanki[3]);
		}
	if(start==3){
		if(zanki[2]>=zanki[3]){
			DrawGraph( 0 , 0 ,image26 , FALSE  ) ;
		}
		else if(zanki[2]<zanki[3]){
			DrawGraph( 0 , 0 ,image27 , FALSE  ) ;
		}
		if(Key[ KEY_INPUT_RETURN   ]==1){
		   e=1;
		}
	}
	if(start==4){
		DrawGraph( 0 , 0 ,image25 , FALSE  ) ;
		if(Key[ KEY_INPUT_RETURN   ]==1){
		   e=1;
		}
	}
	if(start==5||start==7){
		DrawGraph( 0 , 0 ,image24 , FALSE  ) ;
		if(Key[ KEY_INPUT_RETURN   ]==1){
		   e=1;
		}
	}
	if(start==6){
		if(zanki[1]>=zanki[2]&&zanki[1]>=zanki[3]){
			DrawGraph( 0 , 0 ,image25 , FALSE  ) ;
		}
		else if(zanki[2]>=zanki[3]){
			DrawGraph( 0 , 0 ,image26 , FALSE  ) ;
		}
		else {
			DrawGraph( 0 , 0 ,image27 , FALSE  ) ;
		}

		if(Key[ KEY_INPUT_RETURN   ]==1){
		   e=1;
		}
	}
	if(e==1){
			start=0;
			zanki[0]=5;
			zanki[1]=5;
			zanki[2]=5;
			zanki[3]=5;
			a=0;
			b=0;
			c=0;
			d=0;
			oti[0]=0;
			oti[1]=0;
			oti[2]=0;
			oti[3]=0;
			otosi[0]=0;
			otosi[1]=0;
			otosi[2]=0;
			otosi[3]=0;
			x[0]=160;
			x[1]=480;
			x[2]=192;
			x[3]=448;
			y[0]=64;
			y[1]=384;
			y[2]=320;
			y[3]=256;
			f=0;
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i>=2&&i<=12){
					if(j>=5&&j<=15){
						map[i][j]=1;
					}
				}
			}
		}
		for(i=0;i<15;i++){
			for(j=0;j<20;j++){
				if(i>=5&&i<=7){
					if(j>=8&&j<=10){
						map[i][j]=1;
					}
				}
			}
		}
			e=0;
	}


        ScreenFlip();
}
 
    DxLib_End();
    return 0;
}