#define IDI_ICON1 102
#define IDI_ICON2 103

